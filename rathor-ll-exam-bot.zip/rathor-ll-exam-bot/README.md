# RATHOR LL EXAM BOT

A responsive static frontend starter for GitHub Pages.

## Publish with GitHub Pages (mobile or desktop)
1. Sign in at https://github.com and create a **public** repository named `rathor-ll-exam-bot`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then Save.
6. Wait for the Pages deployment. The site URL will be `https://YOUR-USERNAME.github.io/rathor-ll-exam-bot/`.

## Important API security note
This is only the public frontend. The four supplied Supabase URLs contain a placeholder API key, and their actual request/response schemas have not been verified. Do not replace the placeholder with a real key in `index.html`: GitHub Pages source is public and browser requests expose credentials. Configure a private backend proxy (for example, a server-side function with secrets stored as environment variables) and set `API_PROXY_URL` in `index.html` to that proxy. The backend must validate authorization and only perform permitted actions.

The page intentionally does not automate exam answers, bypass identity checks, or impersonate a candidate. It is a dashboard shell for authorized submission, status, screenshot, and password-recovery workflows. Until a secure proxy is configured, API actions are disabled and form values are not transmitted.
